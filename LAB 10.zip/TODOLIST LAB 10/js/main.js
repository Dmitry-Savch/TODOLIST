// Code by DJI

let tasksList = []
let lastIndex = 0

const todoItemTemplate  = document.getElementById('todo-item')
const newItemInput      = document.getElementById('new-item-text')
const todoList          = document.getElementById('todo-list')
const searchBar         = document.getElementById('search-bar')

function search() {
    tasksList.forEach(obj => {
        try {
            todoList.querySelector("#" + obj.taskId).remove()
        } catch {}
    })

    if(searchBar.value != "") {
        tasksList.forEach(obj => {
            if(searchBar.value == obj.text) {
                addSavedTask(obj.taskId, obj.text)
            }
        })
    } 
    else {
        tasksList.forEach(obj => {
            addSavedTask(obj.taskId, obj.text)
        })
    }
}

function saveTasks() {
    if (tasksList.length != 0) {
        localStorage.setItem('taskList', JSON.stringify(tasksList) + "::" + lastIndex)
    } else {
        localStorage.setItem('taskList', '')
    }
}

function addSavedTask(index, text) {
    const newTask = todoItemTemplate.content.cloneNode(true)

    newTask.querySelector('#todo-item-text').innerText = text
    newTask.querySelector('.row').id = index

    newTask.querySelector('img').addEventListener('click', () => {
        todoList.querySelector("#" + index).remove()

        tasksList.forEach(obj => {
            if (obj.taskId == index) {
                objIndex = tasksList.indexOf(obj)
                tasksList.splice(objIndex, 1)

                saveTasks()
                return 0
            }
        })
    })
    todoList.appendChild(newTask)
}

function addTask() {
    if (!newItemInput.value) {
        return 0
    }

    const newTask = todoItemTemplate.content.cloneNode(true)
    const taskId  = "task-" + lastIndex

    newTask.querySelector('#todo-item-text').innerText = newItemInput.value
    newTask.querySelector('.row').id = taskId

    newTask.querySelector('img').addEventListener('click', () => {
        todoList.querySelector("#" + taskId).remove()

        tasksList.forEach(obj => {
            if (obj.taskId == taskId) {
                objIndex = tasksList.indexOf(obj)
                tasksList.splice(objIndex, 1)

                saveTasks()
                return 0
            }
        })
    })

    todoList.appendChild(newTask)
    tasksList.push({'taskId': taskId, 'text': newItemInput.value})

    newItemInput.value = ''
    lastIndex += 1

    saveTasks()
}

const savedTasks = localStorage.getItem('taskList') || ''

if (savedTasks != '') {
    tasksList = JSON.parse(savedTasks.split('::')[0])
    lastIndex = Number(savedTasks.split('::')[1])

    tasksList.forEach(obj => {
        addSavedTask(obj.taskId, obj.text)
    })
}

searchBar.addEventListener('change', search)
document.getElementById('new-item-btn').addEventListener('click', addTask)